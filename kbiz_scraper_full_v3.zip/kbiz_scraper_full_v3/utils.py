
import re
from urllib.parse import urljoin
import httpx
from bs4 import BeautifulSoup

EMAIL_REGEX = re.compile(
    r'([a-zA-Z0-9._%+-]+)\s*(?:@|[(\[]at[)\]]|[(\[]골뱅이[)\]])\s*([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
)

def extract_emails_from_text(text: str):
    found = set()
    for m in EMAIL_REGEX.finditer(text or ""):
        found.add(f"{m.group(1)}@{m.group(2)}")
    return list(found)

async def crawl_site_for_emails(base_url: str, max_pages: int = 5):
    base = base_url.rstrip("/")
    candidates = [
        base,
        urljoin(base + "/", "contact"),
        urljoin(base + "/", "Contact"),
        urljoin(base + "/", "contact-us"),
        urljoin(base + "/", "about"),
        urljoin(base + "/", "privacy"),
        urljoin(base + "/", "개인정보처리방침"),
        urljoin(base + "/", "회사소개"),
    ]
    seen = set()
    emails = set()
    async with httpx.AsyncClient(follow_redirects=True, timeout=15, headers={
        "User-Agent": "kbiz-scraper/0.1"
    }) as client:
        for url in candidates[:max_pages]:
            if url in seen:
                continue
            seen.add(url)
            try:
                r = await client.get(url)
                if r.status_code != 200 or "text/html" not in r.headers.get("content-type",""):
                    continue
                soup = BeautifulSoup(r.text, "lxml")
                emails.update(extract_emails_from_text(soup.get_text(" ", strip=True)))
                for a in soup.select("a[href^='mailto:']"):
                    mail = a.get("href").split("mailto:")[-1].split("?")[0]
                    if mail:
                        emails.add(mail.strip())
            except Exception:
                continue
    ordered = sorted(emails, key=lambda e: (not any(e.lower().startswith(x) for x in ["info@","contact@","sales@","admin@","support@"]), e))
    return ordered
