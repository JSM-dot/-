py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip setuptools wheel
pip install --prefer-binary -r requirements.txt
python -m streamlit run app.py
