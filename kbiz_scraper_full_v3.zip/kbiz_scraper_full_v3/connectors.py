
import os, httpx
from typing import List, Dict, Optional

async def fetch_hira_facilities(sido: str, sggu: Optional[str]=None, api_key: Optional[str]=None) -> List[Dict]:
    key = api_key or os.getenv("HIRA_API_KEY")
    if not key:
        return []
    # 실제 API 연결은 문서에 맞춰 구현 필요. 현재는 데모.
    return []

async def fetch_localdata_business(sido: str, sggu: Optional[str]=None, industry_keyword: Optional[str]=None, api_key: Optional[str]=None) -> List[Dict]:
    key = api_key or os.getenv("LOCALDATA_API_KEY")
    if not key:
        return []
    # 실제 데이터셋 선택 후 구현 필요. 현재는 데모.
    return []

async def find_homepage_via_bing(query: str, api_key: Optional[str]=None) -> Optional[str]:
    key = api_key or os.getenv("BING_API_KEY")
    if not key:
        return None
    headers = {"Ocp-Apim-Subscription-Key": key}
    endpoint = "https://api.bing.microsoft.com/v7.0/search"
    params = {"q": query, "count": 5, "responseFilter": "Webpages"}
    async with httpx.AsyncClient(timeout=15, headers=headers) as client:
        r = await client.get(endpoint, params=params)
        if r.status_code != 200:
            return None
        js = r.json()
        web = js.get("webPages", {}).get("value", [])
        for w in web:
            url = w.get("url")
            if url and "naver.com/map" not in url and "place.map.kakao.com" not in url:
                return url
    return None
