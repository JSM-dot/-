지역·업종 기반 회사정보 수집기

빠른 실행(윈도우)
1 PowerShell에서 폴더로 이동
2 가상환경 생성과 활성화
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
3 패키지 설치
   python -m pip install -U pip setuptools wheel
   pip install --prefer-binary -r requirements.txt
4 실행
   python -m streamlit run app.py
